function displayOverlay() {
    document.getElementById('payolution_overlay').style.display = "";
}
function removeOverlay() {
    document.getElementById('payolution_overlay').style.display = "none";
}
